const help = (prefix) => {
	return `BOT G GUNA
	
	                
MAKER:

 *${prefix}sticker* [foto]
 *${prefix}stickergif* [foto]
 *${prefix}sticker nobg 
 *${prefix}thunder* [teks]
 *${prefix}tsticker* [teks/url]

MEDIA:

 *${prefix}tts* [teks]
 *${prefix}ocr*
 *${prefix}loli*
 *${prefix}toimg*
 *${prefix}meme*
 *${prefix}memeindo*
 *${prefix}nsfwloli*
 *${prefix}wait* [foto]
 *${prefix}simi
 *${prefix}simih*
 *${prefix}wait*

GROUP:

 *${prefix}setname*
 *${prefix}setdesc*
 *${prefix}getpp*
 *${prefix}tagall*
 *${prefix}linkgroup
 *${prefix}gprofile*
 *${prefix}setprefix
 *${prefix}welcome*
 *${prefix}left*

SOUND:

 *salam*
 *tariksis*
 *baka*
 *desah*
 *goblok*
 *roti*
 *welot*
 *abangjago*`
}

exports.help = help

