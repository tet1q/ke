const donasi = () => {
	return `BOT G GUNA	

  Hi kamu...
  
      Kamu tau gak?.... sebenernya...
       Aku suka sama kamu:v`
}

exports.donasi = donasi
